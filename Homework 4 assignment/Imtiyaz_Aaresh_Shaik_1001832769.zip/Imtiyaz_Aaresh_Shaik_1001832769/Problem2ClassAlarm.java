package Homework4;

public class Problem2ClassAlarm {

		boolean redLight,yellowLight,greenLight,strobe,bell;

		public boolean isRedLight() {
			return redLight;
		}

		public void setRedLight(boolean redLight) {
			this.redLight = redLight;
		}

		public boolean isYellowLight() {
			return yellowLight;
		}

		public void setYellowLight(boolean yellowLight) {
			this.yellowLight = yellowLight;
		}

		public boolean isGreenLight() {
			return greenLight;
		}

		public void setGreenLight(boolean greenLight) {
			this.greenLight = greenLight;
		}

		public boolean isStrobe() {
			return strobe;
		}

		public void setStrobe(boolean strobe) {
			this.strobe = strobe;
		}

		public boolean isBell() {
			return bell;
		}

		public void setBell(boolean bell) {
			this.bell = bell;
		}
}